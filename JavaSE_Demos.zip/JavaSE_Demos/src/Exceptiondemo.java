
public class Exceptiondemo {
		 
	public static void main(String[] args) {
		String str=null;
		str.equals("Hello");
	}
	}
   
   

