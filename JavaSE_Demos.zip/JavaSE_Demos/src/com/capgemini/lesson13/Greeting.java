package com.capgemini.lesson13;


public class Greeting {
	public String greet()
	{
		return "WELCOME TO JAVA";
	}
}
