package com.cg.SeleniumGrid;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

public class SeleniumGrid {

	public String driverPath = "D:\\Selenium Grid";
	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\Users\\kmokati\\Downloads\\chromedriver_win32\\chromedriver.exe");
		DesiredCapabilities capability = DesiredCapabilities.firefox();
		capability.setBrowserName("firefox");
		capability.setPlatform(Platform.ANY);
		//DesiredCapabilities capability = DesiredCapabilities.chrome();
		//capability.setBrowserName("chrome");
		//capability.setVersion(Version.getVersion());
		//capability.setVersion("50.5");
		//DesiredCapabilities capabiltiy = DesiredCapabilities.internetExplorer();
		//capability.setBrowserName("internetexplorer");
		//capability.setPlatform(Platform.ANY);
		WebDriver driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), capability);
		//new RemoteWebDrriver(new URL("http:10.51.16.105"),capability);
		try{
			driver.navigate().to("file:///D:/Users/kmokati/Desktop/M4%20HTML%20file/Coaching_Class_Enquiry.html");
			
			 driver.findElement(By.xpath(".//*[@id='fname']")).sendKeys("Yashasvi"); // first name entry
		       Thread.sleep(2000);
		       driver.findElement(By.xpath(".//*[@id='lname']")).sendKeys("Ryali"); //last name entry
	           Thread.sleep(2000);
	           
	           driver.findElement(By.xpath(".//*[@id='emails']")).sendKeys("Ryali@gamil.com");// email
	           Thread.sleep(2000);
	          
	           driver.findElement(By.xpath(".//*[@id='mobile']")).sendKeys("9876543211");// phone number
	           Thread.sleep(2000);
	          
	           Select tuitionType= new Select(driver.findElement(By.name("D6"))); //tuition type 
	           tuitionType.selectByIndex(1);
	   		   
	           Select cityPreference= new Select(driver.findElement(By.xpath("html/body/form/table/tbody/tr[7]/td[2]/select"))); //city preference
	           cityPreference.selectByIndex(1);
	   		   
	   		   Select modeOfLearning= new Select(driver.findElement(By.xpath("html/body/form/table/tbody/tr[8]/td[2]/select"))); // mode of learning
	   		   modeOfLearning.selectByIndex(1); 

	   		driver.findElement(By.xpath("html/body/form/table/tbody/tr[8]/td[2]/select/option[3]")).click(); 
	        Thread.sleep(2000);
	        driver.findElement(By.id("Submit1")).submit();
	        Thread.sleep(2000);
	        
	        Alert alert = driver.switchTo().alert();
	        boolean enquiry = alert.getText().contains("Enquiry details must be filled out"); 
	        alert.accept();
	        System.out.println(enquiry);
	        
	        driver.findElement(By.xpath(".//*[@id='enqdetails']")).sendKeys("why when how and what?"); // enquiry details
	        Thread.sleep(2000);
	        driver.findElement(By.id("Submit1")).submit(); // submit buton
	        
	        alert = driver.switchTo().alert();
	        boolean submit = alert.getText().contains("Thank you for submitting the online coaching Class Enquiry");
	        alert.accept();
	        System.out.println(submit);
             driver.close();
             
		}
		finally{
			
		}
		
}}
