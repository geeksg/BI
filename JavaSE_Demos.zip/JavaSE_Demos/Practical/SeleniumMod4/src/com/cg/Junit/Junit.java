package com.cg.Junit;

import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Junit {
	WebDriver driver;
	@Before
	public void bfr()
	{
		driver = new FirefoxDriver();
		driver.navigate().to("file:///D:/Users/kmokati/Desktop/M4%20HTML%20file/Coaching_Class_Enquiry.html");
		driver.manage().window().maximize();
	}
  @org.junit.Test
  public void enquiryForm() throws InterruptedException {
	  
	  
		 String actualTitle = driver.getTitle();
	     String expectedTitle = "Online Coaching Class Enquiry Form";
	     if(actualTitle.equals(expectedTitle))
	     { 
	    	 System.out.println("Title Matched");
	    	 Thread.sleep(5000);
	     }
	     else {
	    	 System.out.println("Title does not match");
	     }
	     driver.findElement(By.xpath(".//*[@id='fname']")).sendKeys("Yashasvi"); // first name entry
	       Thread.sleep(2000);
	       driver.findElement(By.xpath(".//*[@id='lname']")).sendKeys("Ryali"); //last name entry
           Thread.sleep(2000);
           
           driver.findElement(By.xpath(".//*[@id='emails']")).sendKeys("Ryali@gamil.com");// email
           Thread.sleep(2000);
          
           driver.findElement(By.xpath(".//*[@id='mobile']")).sendKeys("9876543211");// phone number
           Thread.sleep(2000);
          
           Select tuitionType= new Select(driver.findElement(By.name("D6"))); //tuition type 
           tuitionType.selectByIndex(1);
   		   
           Select cityPreference= new Select(driver.findElement(By.xpath("html/body/form/table/tbody/tr[7]/td[2]/select"))); //city preference
           cityPreference.selectByIndex(1);
   		   
   		   Select modeOfLearning= new Select(driver.findElement(By.xpath("html/body/form/table/tbody/tr[8]/td[2]/select"))); // mode of learning
   		   modeOfLearning.selectByIndex(1); 

   		driver.findElement(By.xpath("html/body/form/table/tbody/tr[8]/td[2]/select/option[3]")).click(); 
        Thread.sleep(2000);
        driver.findElement(By.id("Submit1")).submit();
        Thread.sleep(2000);
        
        Alert alert = driver.switchTo().alert();
        boolean enquiry = alert.getText().contains("Enquiry details must be filled out"); 
        alert.accept();
        System.out.println(enquiry);
        
        driver.findElement(By.xpath(".//*[@id='enqdetails']")).sendKeys("why when how and what?"); // enquiry details
        Thread.sleep(2000);
        driver.findElement(By.id("Submit1")).submit(); // submit buton
        
        alert = driver.switchTo().alert();
        boolean submit = alert.getText().contains("Thank you for submitting the online coaching Class Enquiry");
        alert.accept();
        System.out.println(submit);
             
  }
  
  
  
  @After
	public void afrclass()
	{
		driver.close();
	}
}
