package com.cg.SeleniumGrid;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;

public class DemoPhantom {
public static void main(String[] args) {
	File file = new File("C:\\phantomjs-2.1.1-windows\\phantomjs-2.1.1-windows\\bin\\phantomjs.exe");
	System.setProperty("phantomjs.binary.path", file.getAbsolutePath());

 WebDriver driver = new PhantomJSDriver();
 driver.get("https://www.google.co.in/search?q=w3schools&oq=w3&aqs=chrome.1.69i57j0j69i60j0j69i60j0.1347j1j9&sourceid=chrome&ie=UTF-8");
 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
 System.out.println(driver.getTitle());

 //Boolean title= driver.getTitle().contains("")
 //System.out.println(title);
}
}
