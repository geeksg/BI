package com.cg.SeleniumGrid;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class DemoGrid1 {
	

	public String driverPath = "D:\\Selenium Grid";
	public static void main(String[] args) throws MalformedURLException {
		System.setProperty("webdriver.chrome.driver","D:\\Users\\kmokati\\Downloads\\chromedriver_win32\\chromedriver.exe");
		DesiredCapabilities capability = DesiredCapabilities.firefox();
		capability.setBrowserName("firefox");
		capability.setPlatform(Platform.ANY);
		//DesiredCapabilities capability = DesiredCapabilities.chrome();
		//capability.setBrowserName("chrome");
		//capability.setVersion(Version.getVersion());
		//capability.setVersion("50.5");
		WebDriver driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), capability);
		//new RemoteWebDrriver(new URL("http:10.51.16.105"),capability);
		try{
			driver.get("http://demo.opencart.com/");
             
		}
		finally{
			
		}
		
}
}