package com.cg.SeleniumGrid;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

public class DemoHTMlUnit {

	public static void main(String[] args) {
		WebDriver driver = new HtmlUnitDriver();
		driver.get("https://www.google.co.in/search?q=w3schools&oq=w3&aqs=chrome.1.69i57j0j69i60j0j69i60j0.1347j1j9&sourceid=chrome&ie=UTF-8");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Boolean title = driver.getTitle().contains("Google");
		System.out.println(title);
	}

}
