package com.cg.TestNG;

import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetTitle {
	WebDriver driver;

	@BeforeClass
	public void bfclass() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Users\\kmokati\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to("file:///D://Users//kmokati//Desktop//module%204//Lesson%205-HTML%20Pages//Lesson%205-HTML%20Pages//Lesson%205-HTML%20Pages//AlertExample.html");
	}

	@Test
	public void test() {
		//string acttitle = driver.getTitle();
		//string exptitle = "Hello";
		//Assert.asserEquals(exptitle,acttitle);
		AssertJUnit.assertEquals("Title is not matching", "",driver.getTitle());
		driver.findElement(By.name("btnAlert")).click();
		Alert alert = driver.switchTo().alert();
		alert.accept();

	}

	@AfterClass()
	public void test1() {
		driver.close();
	}
}
