package com.cg.TestNG;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CountLinks2 {
	
	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
		driver.get("http//demo.opencart.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
	
		
		driver.navigate().to("http://demo.opencart");
		
	
	}
  
}
