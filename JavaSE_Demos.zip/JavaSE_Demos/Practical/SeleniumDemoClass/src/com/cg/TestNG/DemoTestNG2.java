package com.cg.TestNG;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class DemoTestNG2 {
	@BeforeTest
	public void bfttest()
	{
		System.out.println("Before test");
	}
	@Test(priority=1)
	public void Login()
	{
		System.out.println("Login");
	}
	@Test(priority=2)
	public void delete()
	{
		
		System.out.println("delete");
	}
	@AfterTest
	public void aftMethod()
	{
		System.out.println("After test");
	}
}
