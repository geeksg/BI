package com.cg.TestNG;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class DemoTestNG1 {
  		@BeforeMethod
		public void bftMethod()
		{
			System.out.println("Before execution");
		}
		@Test(priority=1)
		public void update()
		{
			System.out.println("Update");
		}
		@Test(priority=2)
		public void delete()
		{
			System.out.println("delete");
		}
		@AfterMethod
		public void aftMethod()
		{
			System.out.println("After execution");
		}
}
