package com.cg.TestNG;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
//counting links using testNG
public class CountLinks3 {
	WebDriver driver;
	@BeforeClass
	public void bfr()
	{
		driver = new FirefoxDriver();
		driver.get("https://www.google.com/search?q=seleniumhq&ie=utf-8&oe=utf-8&aq=t&rls=org.mozilla:en-GB:official&client=firefox-a&channel=np&source=hp");
	}
	@Test
	public void NoOfLinks() 
	{
		List<WebElement> elements = driver.findElements(By.tagName("a"));
		String[] text = new String[elements.size()];
		System.out.println("Total Number of Hyper Links = "+elements.size());
		
		int count = 0;
		
		//getting links in the web page
		
		for(WebElement e : elements)
		{
			text[count] = e.getText();
			System.out.println("The hyperlink name is: " +text[count]);
			count++;
		}		
	}
	@AfterClass
	public void afrclass()
	{
		driver.close();
	}

}
