package com.cg.TestNG;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

//import org.testng.annotations.Test;
// counting links in a main method 
public class CountLinks {
	// WebDriver driver;
	// @BeforeClass
	public static void main(String[] args) {

		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.google.com/search?q=seleniumhq&ie=utf-8&oe=utf-8&aq=t&rls=org.mozilla:en-GB:official&client=firefox-a&channel=np&source=hp");

		// @Test
		List<WebElement> elements = driver.findElements(By.tagName("a"));
		String[] text = new String[elements.size()];
		System.out.println("Total Number of Hyper Links = " + elements.size());

		int count = 0;

		// getting links in the web page

		for (WebElement e : elements) {
			text[count] = e.getText();
			System.out.println("The hyperlink name is: " + text[count]);
			count++;
		}
	}

}
