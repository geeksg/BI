package com.cg.TestNG;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class DemoTestNG3 extends DemoTestNG2 {
	@BeforeClass
	public void bftclss()
	{
		System.out.println("Before execution");
	}
	@Test(priority=1)
	public void update()
	{
		System.out.println("Update");
	}
	@Test(priority=2)
	public void delete()
	{
		
		System.out.println("delete");
	}
	@AfterClass
	public void aftclss()
	{
		System.out.println("After execution");
	}
  }

