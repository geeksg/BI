package testWebDriver;

 import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class AlertSample {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new FirefoxDriver();

		driver.get("https://www.naukri.com/");
		
		//Thread.sleep(5000);
		
		//driver.findElement(By.id("newtab")).click();
		
		String parentWindow=driver.getWindowHandle();
		//WebDriverWait wait = new WebDriverWait(driver,10);
		
		System.out.println("Parent Window: "+parentWindow);
		for (String childWindow : driver.getWindowHandles())
		{
		  if(!childWindow.equals(parentWindow))
		 {
						driver.switchTo().window(childWindow);
						driver.close();
						Thread.sleep(10000);
						driver.switchTo().window(parentWindow);		
						Thread.sleep(5000);
						  }
						}
						driver.switchTo().window(parentWindow);
						driver.close();
					}
		
		
		
		

		

	
	
	}
	
	
	

