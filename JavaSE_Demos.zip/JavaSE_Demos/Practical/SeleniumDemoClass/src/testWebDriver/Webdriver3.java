package testWebDriver;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Webdriver3 {
public static void main(String[] args) throws InterruptedException {
	 WebDriver driver = new FirefoxDriver();
     //driver.manage().deleteAllCookies();
     driver.navigate().to("https://demo.opencart.com/");
     //driver.navigate().to("https://demo.opencart.com/");
     driver.manage().window().maximize();
     String actualTitle = driver.getTitle();
     String expectedTitle = "Your Store";
     if(actualTitle.equals(expectedTitle))
     { 
    	 System.out.println("Title Matched");
    	 Thread.sleep(5000);
     }
     else {
    	 System.out.println("Title does not match");
     }
    	 driver.findElement(By.xpath("html/body/nav/div/div[2]/ul/li[2]/a/span[1]")).click();  
     driver.findElement(By.xpath("html/body/nav/div/div[2]/ul/li[2]/ul/li[1]/a")).click();
     Thread.sleep(5000);
     /*driver.getPageSource().contains("Register Account");
     System.out.println("Title on register page Matched");*/
     
     actualTitle = driver.getTitle();
     expectedTitle = "Register Account";
     if(actualTitle.equals(expectedTitle))
     { 
    	 System.out.println("Title on register page Matched");
    	 Thread.sleep(5000);
     }
     else {
    	 System.out.println("Title not matching");
     }
 
    driver.findElement(By.xpath(".//*[@id='content']/form/div/div/input[2]")).click();
    String actualText = driver.findElement(By.xpath("html/body/div[2]/div[1]")).getText();
    String expectedText =  "Warning: You must agree to the Privacy Policy!";
    Thread.sleep(5000);
    Assert.assertEquals(expectedText, actualText);
    
    
    driver.findElement(By.xpath("html/body/div[2]/div[2]/div/form/fieldset[1]/div[2]/div/input")).sendKeys("abcdefgijklmnopqrstuvwxyzabadfsdgsdfhad"); //Entering invalid first name
    Thread.sleep(5000);
    driver.findElement(By.xpath(".//*[@id='content']/form/div/div/input[2]")).click(); //continue button clicked
    String actualName = driver.findElement(By.xpath(".//*[@id='account']/div[2]/div/div")).getText();
    String expectedName =  "First Name must be between 1 and 32 characters!";
    Assert.assertEquals(expectedName, actualName);
    System.out.println("First-Name warning matched");
    
    driver.findElement(By.xpath("html/body/div[2]/div[2]/div/form/fieldset[1]/div[2]/div/input")).clear(); //Clearing first name 
    driver.findElement(By.xpath("html/body/div[2]/div[2]/div/form/fieldset[1]/div[2]/div/input")).sendKeys("abcdefgijklmnopqrstuvwxyzab"); //Entering valid first name 
    Thread.sleep(5000);
    driver.findElement(By.xpath(".//*[@id='content']/form/div/div/input[2]")).click(); //continue button clicked
    /*if(actualName.equals("First Name must be between 1 and 32 characters!"))
    {
    	System.out.println("First name alert text matches");
    }
    else
    {
        System.out.println("Text didn't match");
    }*/
    driver.findElement(By.xpath(".//*[@id='input-lastname']")).sendKeys("abcdefgijklmnopqrstuvwxyzaafsgsgdbdgfgag");//Entering invalid last name 
    Thread.sleep(5000);
    driver.findElement(By.xpath(".//*[@id='content']/form/div/div/input[2]")).click(); //continue button clicked
    String actualLname = driver.findElement(By.xpath(".//*[@id='account']/div[3]/div/div")).getText();
    String expectedlLname = "Last Name must be between 1 and 32 characters!";
    Assert.assertEquals(expectedlLname, actualLname);
    System.out.println("Last-Name warning matched");
   
     driver.findElement(By.xpath(".//*[@id='input-lastname']")).clear(); //Clearing last name
     driver.findElement(By.xpath(".//*[@id='input-lastname']")).sendKeys("abcdefgijklmnopqrstuvwxyzab"); //Entering valid last name  
     Thread.sleep(5000);
     driver.findElement(By.xpath(".//*[@id='content']/form/div/div/input[2]")).click(); //continue button clicked
     driver.findElement(By.xpath("html/body/div[2]/div[2]/div/form/fieldset[1]/div[4]/div/input")).sendKeys("karthikmani@gmail.com");
		driver.findElement(By.xpath(".//*[@id='input-telephone']")).sendKeys("1234567");
	    driver.findElement(By.xpath(".//*[@id='input-password']")).sendKeys("1234567");
		driver.findElement(By.xpath(".//*[@id='input-confirm']")).sendKeys("1234567");
		driver.findElement(By.xpath(".//*[@id='content']/form/div/div/input[1]")).click();
		driver.findElement(By.xpath(".//*[@id='content']/form/div/div/input[2]")).click();
		driver.findElement(By.xpath(".//*[@id='column-right']/div/a[5]")).click();
		driver.findElement(By.xpath(".//*[@id='content']/div/div[2]/a")).click();
		driver.findElement(By.xpath(".//*[@id='input-address-1']")).sendKeys("Kundalahalli Colony Bangalore");
		driver.findElement(By.xpath(".//*[@id='input-city']")).sendKeys("Bangalore");
		driver.findElement(By.xpath(".//*[@id='input-postcode']")).sendKeys("14875");
    
     

}
}
