package testWebDriver;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.*;


public class TestWebDriverTSFF {
	public static void main(String[] args) throws InterruptedException {
	
		WebDriver driver = new FirefoxDriver();
		driver.get("file:///C:/Users/pmaturi/Desktop/Module-4/Lesson%205-HTML%20Pages/Lesson%205-HTML%20Pages/WorkingWithForms.html");
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.close();
	}
}