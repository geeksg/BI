package testWebDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestWebDriverTSChrome {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","D:\\Users\\kmokati\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.com/");
		//driver.manage().window().maximize();
		driver.findElement(By.id("lst-ib")).sendKeys("seleniumhq");
		driver.findElement(By.name("btnK")).click();
		driver.findElement(By.linkText("Selenium - Web Browser Automation")).click();
		driver.findElement(By.id("q")).sendKeys("selenium");
		driver.findElement(By.name("submit")).click();
		Thread.sleep(5000);
		driver.close();
		
		
		
		
		
		
	}
	
	
	
	
	
}
