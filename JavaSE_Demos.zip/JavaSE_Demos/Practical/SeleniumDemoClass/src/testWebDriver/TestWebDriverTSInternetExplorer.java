package testWebDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class TestWebDriverTSInternetExplorer {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.ie.driver","C:\\Users\\pmaturi\\Downloads\\IEDriverServer.exe");
		WebDriver driver = new InternetExplorerDriver();
		driver.get("file:///C:/Users/pmaturi/Desktop/Module-4/Lesson%205-HTML%20Pages/Lesson%205-HTML%20Pages/WorkingWithForms.html");
		driver.manage().window().maximize();
		driver.findElement(By.id("lst-ib")).sendKeys("seleniumhq");
		driver.findElement(By.name("btnk")).click();
		driver.findElement(By.linkText("Selenium - Web Browser Automation")).click();
		driver.findElement(By.id("q")).sendKeys("selenium");
		driver.findElement(By.name("submit")).click();
		Thread.sleep(10000);
		driver.close();
}
	
}
