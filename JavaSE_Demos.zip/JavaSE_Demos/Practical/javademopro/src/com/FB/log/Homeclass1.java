package com.FB.log;

import com.Appli.login.*;
//import com.Appli.login.Mtdconstructoroverload;

public class Homeclass1 {

	public static void main(String[] args) {
		Mtdconstructoroverload mtd1 = new Mtdconstructoroverload();
		mtd1.Test1(2,3.6);
		System.out.println("Homepage package Homeclass1");
		Inheritancedemo i1 = new Inheritancedemo();
		i1.Test2();
	}

	public void validateHomePage() {
		System.out.println("Executing validateHomePage method");
	}
}
