package com.Appli.login;

public class Constructordemo {

	 Constructordemo(int a, int b)//default constructor
	 { 
		 System.out.println("Executing default constructor");
		 System.out.println("Executing default constructor 10"+a);
		 System.out.println("Executing default constructor 20"+b);
	 }
	public static void main(String[] args) {
		
		Constructordemo condemo= new Constructordemo(10,20);
		condemo.Test3();
	}
      void Test3()
      {
    	  System.out.println("Executing Test 3 method");
      }
}
