package com.Appli.login;

public class Dividebyzero {

	public static void main(String[] args) {
		
		int a=10;
		int b=0;
		try
		{
			int c= a/b;
			System.out.println("c is" +c);
		}
		
	 catch(ArithmeticException e)
		{
		  System.out.println(e.getMessage());
		 System.out.println("Division by zero");
		}
			
	
	}
	
}
