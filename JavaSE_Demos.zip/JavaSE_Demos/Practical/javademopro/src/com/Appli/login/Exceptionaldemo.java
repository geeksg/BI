package com.Appli.login;

public class Exceptionaldemo {

	public static void main(String[] args) {
		String str=null;
		str.equals("Hello");
	}

}


		 

   