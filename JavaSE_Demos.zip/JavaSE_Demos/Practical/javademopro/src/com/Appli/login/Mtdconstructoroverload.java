package com.Appli.login;

public class Mtdconstructoroverload {
	public static void main(String[] args) {
		Mtdconstructoroverload cls1 = new Mtdconstructoroverload();
		cls1.Test1(1,30);
	}

	public void Test1(int a, double b) {
		System.out.println("1st parameter");
	}

	public void Test1(double a, double b) {
		System.out.println("2nd parameter");
	}

	/*
	 * void Test1(int a, int b, int c) { System.out.println("3rd parameter"); }
	 */

}
