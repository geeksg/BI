package com.Appli.login;

import java.util.Scanner;


public class Scannerdemo {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner (System.in);
		System.out.println("ask onw value " );
		int a=sc.nextInt();
	System.out.println("asked onw value "+a); 
	String str1 = new String("Hello");
	
	String str2 = "Welcome";
	System.out.print("The value of string 1:"+str1+ "  " + str2+"-------> ");
	System.out.println(str1.equals(str2));
	}   
		
	
}
