package com.Appli.login;

interface democlass
{
	int a =10;
  public void Test1();
}


public class Demointerface implements  democlass{

	public static void main(String[] args) {
}

	public void Test1()
	{
		System.out.println("hello");
	}
	
}
