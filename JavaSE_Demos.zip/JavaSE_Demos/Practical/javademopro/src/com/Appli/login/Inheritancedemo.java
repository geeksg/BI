package com.Appli.login;

 class superclass
{
public void Test1() {
	/*System.out.println("Execute Test1 method A");*/
}
public void Test2() {
	System.out.println("Execute Test2 method B");
}
}

class subclass extends superclass
{public void Test3()
{    super.Test1(); 
	System.out.println("Exectuing Test3 method C");
}

}




public class Inheritancedemo extends subclass{

	public static void main(String[] args) {
		subclass sub= new subclass();
		sub.Test1();
		sub.Test2();
		sub.Test3();

	}

}
