package com.Appli.login;

public class Logindemo1 {
	static int a = 10;// static global variable
	int b = 20;// non-static global variable

	public static void main(String[] args) {
		System.out.println("The value of 1 is" + a);
				Logindemo1.Test2();// standard type of calling (method calling)
		// Test2(); calling (other type of method calling)
		// creating an object of class
		Logindemo1 login = new Logindemo1();// creating an object of class to
											// access method calling.
		login.Test1();

	}

	void Test1()// sub method
	{
		System.out.println("The value of 3 is" + a);
		System.out.println("The value of 4 is" + b);
	}

	static void Test2() {
		System.out.println("The value of 2 is" + a);
	}

}
