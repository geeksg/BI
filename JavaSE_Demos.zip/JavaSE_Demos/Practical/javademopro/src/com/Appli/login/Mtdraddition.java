package com.Appli.login;

public class Mtdraddition {

	public static void main(String[] args) {
		int result =Mtdraddition.Addnum (10,30); 
         System.out.println("The addition of two numbers" +result);
	}
         static int Addnum(int num1, int num2)
         {
        	 int addition= num1 + num2;
        	 return addition;
         }
}
