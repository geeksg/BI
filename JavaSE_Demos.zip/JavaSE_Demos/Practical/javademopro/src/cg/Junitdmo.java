package cg;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class Junitdmo {
@BeforeClass
public static void bfrcls()
{
	System.out.println("Program starts");
}
public void bfrmtd()
{
	System.out.println("Executing before method");
}
	@Test 
	public void Test1()
	{
		System.out.println("Hello");
	}
	@Ignore
	@Test 
	public void Test2()
	{
		System.out.println("Welcome");
	}
	@After
	public void aftrmtd()
	{
		System.out.println("Executng after method");
	}
	@AfterClass 
	public static void aftrcls()
	{
		System.out.println("Program ends");
	}
}
