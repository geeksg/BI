package com.cg.helper;

import java.util.ArrayList;
import java.util.Iterator;

import com.cg.bean.Bookschema;

public class BookCollectionHelper {

	private static ArrayList<Bookschema> bookList = null;

	static {
		bookList = new ArrayList<Bookschema>(); // creating an object of book
												// schema class

		Bookschema b1 = new Bookschema(111, "math", 150);
		Bookschema b2 = new Bookschema(101, "english", 260);
		Bookschema b3 = new Bookschema(121, "science", 110);
		bookList.add(b1);
		bookList.add(b2);
		bookList.add(b3);
	}

	//  public BookCollection helper() {}

	public void addNewBookDetails(Bookschema book) {
		bookList.add(book);
	}

	public static ArrayList<Bookschema> getbookList() {
		return getbookList();
	}

	public static void setbookList(ArrayList<Bookschema> bookList) {
		BookCollectionHelper.bookList = bookList;
	}

	public static void displayBookCount() {
		System.out.println(bookList.size());

		Iterator<Bookschema> bookIt = bookList.iterator();

		Bookschema tempBook = null;

		int totalCount = 0;
		while (bookIt.hasNext()) {
			totalCount++;
			tempBook = bookIt.next();
			System.out.println(tempBook);
		}

		System.out.println("Total Count of Books" + totalCount);
	}

}
