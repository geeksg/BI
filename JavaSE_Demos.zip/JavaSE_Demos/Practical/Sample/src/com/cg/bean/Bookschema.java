package com.cg.bean;

public class Bookschema {
	private int bookID;
	private String bookName;
	private double bookPrice;

	public Bookschema(int bookID, String bookName, double bookPrice) {
		this.bookID = bookID;
		this.bookName = bookName;
		this.bookPrice = bookPrice;
	}

	public double getbookPrice() {
		return bookPrice;
	}

	public void setbookPrice(double bookPrice) {
		this.bookPrice = bookPrice;
	}

	public String getbookName() {
		return bookName;
	}

	public void setbookName(String bookName) {
		this.bookName = bookName;
	}

	public int getbookID() {
		return bookID;
	}

	public void setbookID(int bookID) {
		this.bookID = bookID;
	}

	public String toString() {
		return "Book details are " + bookID + " " + bookName + " " + bookPrice;
	}

}
