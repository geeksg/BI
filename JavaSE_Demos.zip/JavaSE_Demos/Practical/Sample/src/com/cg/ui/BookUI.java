package com.cg.ui;

import java.util.Scanner;

import com.cg.bean.Bookschema;
import com.cg.helper.BookCollectionHelper;
import com.cg.helper.BookValidation;

import exceptionpackage.Bookexception;

public class BookUI {

	static Scanner sc = new Scanner(System.in);
	static BookCollectionHelper collectionhelper = null;

	public static void main(String[] args) {
		int choice = 0;
		collectionhelper = new BookCollectionHelper();

		while (true) {
			System.out.println("1.Add New Book \n"
					+ "2.Find total no.of books\n 3:Exit");
			System.out.println("\n Enter choice");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				enterNewBookDetails();
				break;
			case 2:
				collectionhelper.displayBookCount();
				break;
			default:
				System.exit(0);
			}
		}
	}

	private static void enterNewBookDetails() {
		System.out.println("How many new books ? ");
		int bcount = sc.nextInt();
		while (bcount != 0) {
			System.out.println("Enter Book ID");
			String bookID = sc.next();
			try {
				if (BookValidation.validatebookID(bookID))
					System.out.println("Enter Book name");
				String bookName = sc.next();
				if (BookValidation.validatebookName(bookName)) {
					System.out.println("Enter price");
					String bookPrice = sc.next();
					if (BookValidation.validatebookPrice(bookPrice)) {
						Bookschema book = new Bookschema(
								Integer.parseInt(bookID), bookName,
								Double.parseDouble(bookPrice));
						collectionhelper.addNewBookDetails(book);
					}
				}
			}

			catch (Bookexception e) {
				System.out.println(e.getMessage());
			}
			bcount--;
		}
	}

}
