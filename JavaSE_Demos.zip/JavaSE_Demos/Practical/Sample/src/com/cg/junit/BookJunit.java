package com.cg.junit;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.bean.Bookschema;
import com.cg.helper.BookCollectionHelper;
import exceptionpackage.Bookexception;

public class BookJunit {
	static BookCollectionHelper collectionHelper;
	static Bookschema book = null;

	@BeforeClass
	public static void beforeClass() {
		collectionHelper = new BookCollectionHelper();
		book = new Bookschema(888, "Java book", 670.50);
	}

	@AfterClass
	public static void afterClass() {
		collectionHelper = null;
		book = null;
	}

	@Test
	public void addNewBookDetails() throws Bookexception {
		collectionHelper.addNewBookDetails(book);
		//Assert.assertEquals(3,collectionHelper.getbookList().size());
		Assert.assertNotNull(collectionHelper.toString());
	}
}
