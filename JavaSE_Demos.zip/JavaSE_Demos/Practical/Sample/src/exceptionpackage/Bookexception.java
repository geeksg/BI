package exceptionpackage;

public class Bookexception extends Exception {

	public Bookexception(String message) {
		super(message);
	}
}
