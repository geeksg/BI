package com.capgemini.registration.service;

import java.util.regex.Pattern;

import com.capgemini.exception.ExceptionRegistration;

public class RegistrationValidator {

	public static boolean validateContactId(String contactId)
			throws ExceptionRegistration {

		String idPattern = "\\d{3}";
		if (Pattern.matches(idPattern, contactId)) {
			return true;
		} else {
			throw new ExceptionRegistration("ID upto 3 digits is allowed");
		}
	}

	public static boolean validateFirstName(String firstName)
			throws ExceptionRegistration {
		String fPattern = "[a-z]{3,15}";
		if (Pattern.matches(fPattern, firstName)) {
			return true;
		} else {
			throw new ExceptionRegistration(
					"First name should have minimum 3 and maximum 15 alphabets");
		}

	}

	public static boolean validateLastNmae(String lastNmae)
			throws ExceptionRegistration {
		String lPattern = "[a-z]{3,15}";
		if (Pattern.matches(lPattern, lastNmae)) {
			return true;
		} else {
			throw new ExceptionRegistration(
					"Last name should have minimum 3 and maximum 15 alphabets");
		}

	}

	public static boolean validateMobileNo(String mobileNo)
			throws ExceptionRegistration {
		String mPattern = "[789]{1}[0-9]{9}";
		if (Pattern.matches(mPattern, mobileNo)) {
			return true;
		} else {
			throw new ExceptionRegistration(
					"Mobile number should have only a 10-digit number starting with 7/8/9");
		}

	}

	public static boolean validateFlatType(String flatType)
			throws ExceptionRegistration {
		String ftPattern = "1-1BHK|2-2BHK|3-3BHK";
		if (Pattern.matches(ftPattern, flatType)) {
			return true;
		} else {
			throw new ExceptionRegistration(
					"Flat type should be 1BHK or 2BHK or 3BHK");
		}

	}

	public static boolean validateRentAmount(String desiredRentAmount)
			throws ExceptionRegistration {
		String raPattern = "[0-9]{1,}";
		if (Pattern.matches(raPattern, desiredRentAmount)) {
			return true;
		} else {
			throw new ExceptionRegistration(
					"Desired rent amount should contain only digits");
		}

	}

	public static boolean validateDepositAmount(String desiredDepositAmount)
			throws ExceptionRegistration {
		String daPattern = "[0-9]{1,}";
		if (Pattern.matches(daPattern, desiredDepositAmount)) {
			return true;
		} else {
			throw new ExceptionRegistration(
					"Desired deposit amount should contain only digits");
		}

	}

}
