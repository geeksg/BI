package com.capgemini.registration.ui;

import java.util.Scanner;

import com.capgemini.exception.ExceptionRegistration;
import com.capgemini.registration.bean.ContactDetails;
import com.capgemini.registration.service.RegistrationHelper;
import com.capgemini.registration.service.RegistrationValidator;

public class RegistrationClient {

	private static final com.capgemini.registration.bean.ContactDetails ContactDetails = null;
	static Scanner sc = new Scanner(System.in);
	static RegistrationHelper regCollectionHelper = null;

	public static void main(String[] args) {
		int choice = 0;
		regCollectionHelper = new RegistrationHelper();

		while (true) {

			System.out.println("1.Register Flat\n"
					+ "2.Display Details\n 3.Exit ");
			System.out.println("\nEnter details");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				enterDetails();
				break;
			case 2:
				regCollectionHelper.displayFlatDetails();
				break;
			default:
				System.exit(0);
			}

		}

	}

	private static void enterDetails() {
		try {
			System.out.println("Please enter owner first name: ");

			String firstName = sc.next();
			if (RegistrationValidator.validateFirstName(firstName)) {
				System.out.println("Enter Last Name:");
				String lastNmae = sc.next();

				if (RegistrationValidator.validateLastNmae(lastNmae)) {
					System.out.println("Enter Mobile No:");
					String mobileNo = sc.next();
					if (RegistrationValidator.validateMobileNo(mobileNo)) {
						System.out.println("Enter flatType");
						String flatType = sc.next();
						if (RegistrationValidator.validateFlatType(flatType)) {
							System.out.println("Enter Desired Rent Amount");
							String desiredRentAmount = sc.next();
							if (RegistrationValidator
									.validateRentAmount(desiredRentAmount)) {
								System.out
										.println("Enter Desired Deposit Amount");
								String desiredDepositamount = sc.next();
								if (RegistrationValidator
										.validateDepositAmount(desiredDepositamount)) {
									ContactDetails contactList = new ContactDetails(
											firstName,
											lastNmae,
											mobileNo,
											flatType,
											Integer.parseInt(desiredRentAmount),
											Integer.parseInt(desiredDepositamount));
									regCollectionHelper
											.addNewFlatDetails(ContactDetails);
								}
							}
						}

					}
				}
			}
		} catch (ExceptionRegistration e) {
			System.out.println(e.getMessage());
		}

	}

}
