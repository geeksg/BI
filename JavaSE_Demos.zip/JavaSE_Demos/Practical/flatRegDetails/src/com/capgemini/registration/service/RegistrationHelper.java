package com.capgemini.registration.service;

import java.util.ArrayList;
import java.util.Iterator;

import com.capgemini.registration.bean.ContactDetails;

public class RegistrationHelper {

	private static ArrayList<ContactDetails> contactList = null;

	static {
		contactList = new ArrayList<ContactDetails>(); // creating an object of
														// contactdetails
		ContactDetails c1 = new ContactDetails(1, "Ravali", "Saha",
				"9234534500", "1BHK", 8000, 25000);
		ContactDetails c2 = new ContactDetails(2, "Arun", "Kumar",
				"97123456782", "2BHK", 12000, 40000);
		contactList.add(c1);
		contactList.add(c2);
	}

	
	public void addNewFlatDetails(ContactDetails contacts) {
		contactList.add(contacts);
	}

	public static ArrayList<ContactDetails> getContactList() {
		return getContactList();
	}

	public static void setcontactList(ArrayList<ContactDetails> contactList) {
		RegistrationHelper.contactList = contactList;
	}

	public static void displayFlatDetails() {
		Iterator<ContactDetails> details = contactList.iterator();
		ContactDetails tempFlatDetails = null;
		while (details.hasNext()) {
			tempFlatDetails = details.next();
			System.out.println(tempFlatDetails);
		}
	}

}
