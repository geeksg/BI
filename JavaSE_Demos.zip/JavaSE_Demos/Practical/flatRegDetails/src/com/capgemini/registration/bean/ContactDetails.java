package com.capgemini.registration.bean;

public class ContactDetails {
	private int contactId;
	private String firstName;
	private String lastNmae;
	private String mobileNo;
	private String flatType;
	private int desiredRentAmount;
	private int desiredDepositAmount;

	public ContactDetails(int contactId, String firstName, String lastNmae,
			String mobileNo, String flatType, int desiredRentAmount,
			int desiredDepositAmount) {
		this.contactId = contactId;
		this.firstName = firstName;
		this.lastNmae = lastNmae;
		this.mobileNo = mobileNo;
		this.flatType = flatType;
		this.desiredRentAmount = desiredRentAmount;
		this.desiredDepositAmount = desiredDepositAmount;
	}

	public ContactDetails(String firstName2, String lastNmae2,
			String mobileNo2, String flatType2, int parseInt, int parseInt2) {
	
	}

	public int getContactId() {
		return contactId;
	}

	public void setContactId(int contactId) {
		this.contactId = contactId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastNmae() {
		return lastNmae;
	}

	public void setLastNmae(String lastNmae) {
		this.lastNmae = lastNmae;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getFlatType() {
		return flatType;
	}

	public void setFlatType(String flatType) {
		this.flatType = flatType;
	}

	public int getDesiredRentAmount() {
		return desiredRentAmount;
	}

	public void setDesiredRentAmount(int desiredRentAmount) {
		this.desiredRentAmount = desiredRentAmount;
	}

	public int getDesiredDepositAmount() {
		return desiredDepositAmount;
	}

	public void setDesiredDepositAmount(int desiredDepositAmount) {
		this.desiredDepositAmount = desiredDepositAmount;
	}

	public String toString() {
		return "ContactDetails are [contactId=" + contactId + ", firstName="
				+ firstName + ", lastNmae=" + lastNmae + ", mobileNo="
				+ mobileNo + ", flatType=" + flatType + ", desiredRentAmount="
				+ desiredRentAmount + ", desiredDepositAmount="
				+ desiredDepositAmount + "]";
	}

}
