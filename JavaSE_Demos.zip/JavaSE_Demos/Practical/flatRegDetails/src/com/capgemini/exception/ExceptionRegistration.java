package com.capgemini.exception;

public class ExceptionRegistration extends Exception {

	public ExceptionRegistration(String message) {
		super(message);
	}
}
