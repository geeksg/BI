package com.capgemini.junit;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.exception.ExceptionRegistration;
import com.capgemini.registration.bean.ContactDetails;
import com.capgemini.registration.service.RegistrationHelper;

public class RegisterJunit {

	static RegistrationHelper regCollectionHelper;
	static ContactDetails contact = null; 
	
	@BeforeClass
	public static void beforeClass(){
		regCollectionHelper= new RegistrationHelper();
		contact = new ContactDetails(4, "Vishwa", "Nath",
				"92345348060", "1BHK", 8000, 28000);
		
	}
	@AfterClass
	public static void afterClass(){
		regCollectionHelper= null;
		contact = null;
	}
	
	@Test 
	public void addNewFlatDetails() throws ExceptionRegistration{
		regCollectionHelper.addNewFlatDetails(contact);
		Assert.assertNotNull(regCollectionHelper.toString());
		
	}
}
